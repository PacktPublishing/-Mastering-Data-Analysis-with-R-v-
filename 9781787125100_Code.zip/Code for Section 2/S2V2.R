# Read Data
getwd()
vehicle <- read.csv("vehicle.csv", header = TRUE)
head(vehicle)

# Data Review and Data Preparation
str(vehicle)
summary(vehicle)
vehicle$lh[vehicle$lh==0] <- mean(vehicle$lh)
vehicle$lc[vehicle$lc==0] <- mean(vehicle$lc)
summary(vehicle)
pairs(vehicle[3:5])
cor(vehicle[3:5])

# Data Partition
set.seed(1234)
ind <- sample(2, nrow(vehicle), 
              replace = TRUE, 
              prob = c(0.7, 0.3))
training <- vehicle[ind==1,]
testing <- vehicle[ind==2,]
cbind(summary(training$lc), summary(testing$lc))

# CTG Data
CTG <- read.csv("~/Desktop/CTG.csv", header = TRUE)
str(CTG)
CTG$NSP <- as.ordered(CTG$NSP)
CTG$Tendency <- as.factor(CTG$Tendency)
xtabs(~NSP+Tendency, CTG)

# Data Partition
set.seed(333)
ind <- sample(2, nrow(CTG), replace = TRUE, prob = c(0.7, 0.3))
training <- CTG[ind==1,]
testing <- CTG[ind==2,]

# Ordinal Logistic Regression
library(MASS)
model <- polr(NSP~.-LB-MSTV-Nmax-Nzeros-Mean-Median-Max, training, Hess=TRUE)
summary(model)

# p-value Calculation
(ctable <- coef(summary(model)))
p <- pnorm(abs(ctable[,"t value"]), lower.tail = FALSE) *2
(ctable <- cbind(ctable, "p value" = p))

# Confusion matrix and error - training data
pred <- predict(model, training)
(tab <- table(pred, training$NSP))
1- sum(diag(tab))/sum(tab)

# Confusion matrix and error - testing data
pred1 <- predict(model, testing)
(tab1 <- table(pred1, testing$NSP))
1 - sum(diag(tab1))/sum(tab1)

# Accuracy
sum(diag(tab1))/sum(tab1)
n <- table(testing$NSP)
n/sum(n)

# Sensitivity
tab1/colSums(tab1)

# Logistic Regression

# Data
mydata <- read.csv("~/Desktop/binary.csv", header = TRUE)
str(mydata)
head(mydata)
summary(mydata)

# Cross tabulation
xtabs(~admit+rank, data = mydata)

# Changing to factor
mydata$admit <- as.factor(mydata$admit)
mydata$rank <- as.factor(mydata$rank)

# Data partition
set.seed(1234)
ind <- sample(2, nrow(mydata),
              replace = TRUE,
              prob = c(0.6, 0.4))
training <- mydata[ind==1,]
testing <- mydata[ind==2,]

# Logistic regression
mylogit <- glm(admit~  gpa + rank,
    data = training,
    family = "binomial")
summary(mylogit)

# Misclassification error & Confusion matrix - Training
p <- predict(mylogit, training, type = "response")
out <- rep("0", 249)
out[p>0.5] <- "1"
tab <- table(out, training$admit)
tab
1-sum(diag(tab))/sum(tab)

# Misclassification error & Confusion matrix - Testing
p <- predict(mylogit, testing, type = "response")
out <- rep("0", 151)
out[p>0.5] <- "1"
tab <- table(out, testing$admit)
tab
1-sum(diag(tab))/sum(tab)

# Reciever Operating Characteristic (ROC) Curve
library(ROCR)
pred <- prediction(p, training$admit)
roc <- performance(pred, "tpr", "fpr")
plot(roc, colorize = T,
     main = "ROC Curve",
     xlab = "1-Specificity",
     ylab = "Sensitivity")
abline(a=0, b=1)

# Baseline
table(training$admit)

# Geographic Plots
library(googleVis)

# 1. Geographic Map for World
data(Population)
str(Population)
world <- gvisGeoMap(Population, locationvar = 'Country', numvar = 'Population')
plot(world)

# 2. Geographic Map for US States
getwd()
vehicle <- read.csv("vehicle.csv", header = TRUE)
str(vehicle)
tab <- table(vehicle$State)
tab <- data.frame(tab)
tab
state <- gvisGeoMap(tab, "Var1", "Freq",
           options = list(region = "US",
                          dataMode = "regions"))
plot(state)

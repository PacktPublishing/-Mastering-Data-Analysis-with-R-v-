# 1. Install R and RStudio

# 2. Data Vectors
grade <- c(20, 23, 19, 25, 22)
grade
name <- c("John", "Chris", "Julia", "Amy", "Lili")
name

# 3. Data Frame
mydata <- data.frame(grade, name)
mydata

# 4. Directory and Files
getwd()
setwd("/Users/brai/Desktop")
write.csv(mydata, "trial.csv")
newdata <- read.csv("trial.csv", header = TRUE)
newdata

# 5. Data and Functions
data()
data(iris)
str(iris)
summary(iris)
head(iris, 3L)
tail(iris)
head(iris[1:3,2:5])

# Example
vehicle <- read.csv("vehicle.csv", header = TRUE)
str(vehicle)
summary(vehicle)

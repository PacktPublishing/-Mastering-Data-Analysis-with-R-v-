# 1. Data Visualization with Qualitative Data
# Bar plot
data(iris)
str(iris)
tab <- table(iris$Species)
tab
barplot(tab,
        main = "Bar Plot for Species",
        xlab = "Species",
        ylab = "Frequency",
        col = rainbow(3))

# Pie Chart
pie(tab,
    main = "Pie Chart for Species",
    col = rainbow(3))

# 2. Data Visualization with Quantitative Data
# Histogram
hist(iris$Sepal.Length,
     main = "Histogram for Sepal length",
     xlab = "Sepal.Length",
     col = "blue",
     breaks = 15,
     xlim = c(4, 8))

# Scatter plot
plot(iris$Sepal.Length, iris$Sepal.Width,
     col = "blue")
pairs(iris[1:4])

# Package
library(psych)
pairs.panels(iris[1:4])

# 3. Example with vehicle data
getwd()
vehicle <- read.csv("vehicle.csv", header = TRUE)
str(vehicle)
tab <- table(vehicle$State)
tab <- sort(tab)
tab <- tab[tab>50]
pie(tab,
    col = rainbow(5))
hist(vehicle$lc,
     breaks= 60,
     col = rainbow(50),
     xlim = c(0,1000))
pairs.panels(vehicle[2:6])

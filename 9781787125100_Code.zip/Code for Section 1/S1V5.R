# Advanced Visualization
library(ggplot2)
data(iris)
head(iris)

# 1. Histogram
qplot(Sepal.Length, data = iris,
      color = Species,
      binwidth = 0.5,
      main = "Histogram for Sepal Length",
      facets = Species~.)

# 2. Scatter Plot
qplot(Sepal.Length, Sepal.Width, data=iris,
      color = Species,
      facets = Species~.)

# 3. Heatmap
library(d3heatmap)
correlation <- cor(iris[1:4])
d3heatmap(correlation,
          scale = "column",
          colors = "Reds")

# 4. Motion Chart
library(googleVis)
data(Fruits)
head(Fruits)
motion <- gvisMotionChart(Fruits,
                idvar = "Fruit",
                "Year")
plot(motion)

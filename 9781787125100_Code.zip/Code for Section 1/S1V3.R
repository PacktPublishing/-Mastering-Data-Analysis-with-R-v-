# Interactive Visualizations
library(plotly)
data(iris)
str(iris)

# 1. Scatter plot
plot_ly(iris, x = iris$Sepal.Length, y = iris$Sepal.Width,
        mode = "markers",
        color = iris$Petal.Length,
        size = iris$Petal.Width,
        text = paste("Species: ", iris$Species))

# 2. Box Plot
plot_ly(iris, y = iris$Sepal.Length,
        color = iris$Species,
        type = "box")

# 3. Histogram
plot_ly(iris, x = iris$Petal.Width,
        type = "histogram")

# 4. Pie Chart
tab <- table(iris$Species)
tab <- data.frame(tab)
tab
plot_ly(tab, labels = tab$Var1, values = tab$Freq,
        type = "pie")

 

# CTG Data
mydata <- read.csv("~/Desktop/CTG.csv", header = TRUE)
str(mydata)
mydata$NSP <- as.factor(mydata$NSP)

# Data Partition
set.seed(222)
ind <- sample(2, nrow(mydata),
              replace = TRUE,
              prob = c(0.6, 0.4))
training <- mydata[ind==1,]
testing <- mydata[ind==2,]

# Multinomial Logistic Regression
library(nnet)
training$NSP <- relevel(training$NSP, ref="1")
mymodel <- multinom(NSP~.-MLTV - Width - Min - Max - Nmax - Nzeros-Tendency, 
                    data = training)
summary(mymodel)

# 2-tailed Z-test
z <- summary(mymodel)$coefficients/summary(mymodel)$standard.errors
p <- (1 - pnorm(abs(z), 0, 1)) * 2
p

# Confusion Matrix & Misclassification Error - Training Data
p <- predict(mymodel, training)
tab <- table(p, training$NSP)
tab
1- sum(diag(tab))/sum(tab)

# Confusion Matrix & Misclassification Error - Testing Data
p1 <- predict(mymodel, testing)
tab1 <- table(p1, testing$NSP)
tab1
1 - sum(diag(tab1))/sum(tab1)

# Prediction and Model Assessment
n <- table(training$NSP)
n/sum(n)
tab/colSums(tab)
tab1/colSums(tab1)
